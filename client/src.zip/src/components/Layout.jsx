import { NavLink, Outlet } from "react-router-dom";
import { motion } from "framer-motion";
import CrisisButton from "./CrisisButton.jsx";
import logo from "../assets/tulasi-logo.webp";

// `short` is the visible label (from sm up); `label` is what screen readers
// and tooltips get.
const NAV_LINKS = [
  { to: "/", label: "Chat", short: "Chat", icon: "💬", end: true },
  { to: "/doctors", label: "Find a Doctor", short: "Doctors", icon: "🩺" },
];

export default function Layout() {
  return (
    <div className="relative flex h-dvh flex-col overflow-hidden text-slate-800">
      <div className="ambient-bg">
        <div className="ambient-blob-3" />
      </div>

      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-white focus:px-3 focus:py-2 focus:text-slate-900 focus:shadow"
      >
        Skip to main content
      </a>

      <motion.header
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="glass depth-shadow relative z-20 mx-2 mt-2 flex shrink-0 flex-wrap items-center justify-between gap-2 rounded-2xl py-2 pl-3 pr-14 sm:mx-6 sm:mt-4 sm:py-2.5 sm:pl-4 sm:pr-16 xl:pr-4"
      >
        <div className="flex items-center gap-2 sm:gap-3">
          <img
            src={logo}
            alt="Tulasi Health Care"
            className="h-8 w-8 rounded-xl object-cover shadow-sm shadow-blue-900/10 sm:h-11 sm:w-11"
          />
          {/* Logo only on the narrowest phones (under 360px), where five nav
              icons and the help button leave no room for the name. */}
          <div className="hidden leading-tight min-[360px]:block">
            <div className="text-sm font-bold tracking-tight text-blue-900 sm:text-base">
              Tulasi
            </div>
            {/* Hidden on phones so the bar stays one row with the help button. */}
            <div className="hidden text-[9px] font-medium uppercase tracking-wider text-blue-600/80 sm:block sm:text-[11px]">
              A Tulasi Health Care Initiative
            </div>
          </div>
        </div>

        <nav className="flex items-center gap-1 sm:gap-1.5">
          {NAV_LINKS.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.end}
              // Icon-only on phones: the label must still reach screen readers.
              aria-label={link.label}
              title={link.label}
              className={({ isActive }) =>
                `flex items-center gap-1.5 rounded-full px-2 py-1.5 text-xs font-semibold transition-colors sm:px-3.5 sm:text-sm ${
                  isActive ? "bg-blue-700 text-white" : "text-blue-700 hover:bg-blue-50"
                }`
              }
            >
              <span aria-hidden="true">{link.icon}</span>
              <span className="hidden sm:inline">{link.short}</span>
            </NavLink>
          ))}
        </nav>
      </motion.header>

      <main id="main-content" className="relative z-10 flex min-h-0 flex-1 flex-col">
        <Outlet />
      </main>

      <footer className="relative z-10 shrink-0 px-3 py-1.5 text-center text-[10px] leading-snug text-slate-500 sm:py-2 sm:text-xs xl:pr-56">
        <p className="mx-auto max-w-2xl">
          <span className="xl:hidden">Not a therapist, doctor, or emergency service.</span>
          <span className="hidden xl:inline">
            Not a therapist or emergency service. If you are in immediate danger, use the{" "}
            <span className="font-semibold text-slate-700">Get Immediate Help</span> button or contact
            local emergency services.
          </span>
        </p>
      </footer>

      <CrisisButton />
    </div>
  );
}
